# SportsBREAK Admin Architecture

Recommended protected routes:
- /admin
- /admin/events
- /admin/inventory
- /admin/packages
- /admin/hotels
- /admin/suppliers
- /admin/authorizations
- /admin/bookings
- /admin/payments
- /admin/refunds
- /admin/customers
- /admin/promos
- /admin/support
- /admin/reports
- /admin/audit
- /admin/settings

Role permissions:
- super_admin: all
- admin: operational administration
- operations: events, inventory, packages, suppliers
- support: customers, bookings, support
- finance: payments, refunds, reports

All role checks must be enforced server-side/RLS, not merely hidden in the UI.
