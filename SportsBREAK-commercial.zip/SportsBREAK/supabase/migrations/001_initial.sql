create extension if not exists pgcrypto;

create type public.app_role as enum ('super_admin','admin','operations','support','finance');
create type public.inventory_status as enum ('available','held','sold','cancelled','disabled');
create type public.booking_status as enum ('draft','awaiting_payment','payment_processing','paid','confirmed','supplier_confirmation_pending','ticket_issued','completed','cancelled','refunded');
create type public.payment_status as enum ('pending','processing','paid','failed','cancelled','refund_pending','refunded');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.user_roles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  role public.app_role not null default 'support'
);

create table public.venues (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  city text not null,
  country text not null,
  address text,
  created_at timestamptz not null default now()
);

create table public.teams (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  country text,
  created_at timestamptz not null default now()
);

create table public.events (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  starts_at timestamptz not null,
  venue_id uuid references public.venues(id),
  status text not null default 'draft',
  is_demo boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.suppliers (
  id uuid primary key default gen_random_uuid(),
  company_name text not null,
  supplier_type text not null,
  contact_name text,
  email text,
  country text,
  contract_reference text,
  status text not null default 'pending',
  notes text,
  created_at timestamptz not null default now()
);

create table public.supplier_authorizations (
  id uuid primary key default gen_random_uuid(),
  supplier_id uuid not null references public.suppliers(id),
  event_id uuid references public.events(id),
  authorization_reference text not null,
  valid_from date,
  valid_until date,
  status text not null default 'pending',
  evidence_uri text,
  created_at timestamptz not null default now()
);

create table public.ticket_inventory (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id),
  supplier_id uuid not null references public.suppliers(id),
  authorization_id uuid references public.supplier_authorizations(id),
  category text not null,
  section_zone text,
  seat_info text,
  quantity integer not null check(quantity > 0),
  price numeric(12,2) not null check(price >= 0),
  currency char(3) not null,
  status public.inventory_status not null default 'available',
  hold_expires_at timestamptz,
  supplier_reference text,
  is_demo boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.ticket_holds (
  id uuid primary key default gen_random_uuid(),
  inventory_id uuid not null references public.ticket_inventory(id),
  user_id uuid references public.profiles(id),
  quantity integer not null check(quantity > 0),
  expires_at timestamptz not null,
  released_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.hotels (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  location text not null,
  description text,
  images text[] not null default '{}',
  rating numeric(2,1),
  supplier_id uuid references public.suppliers(id),
  supplier_reference text,
  cancellation_policy text,
  created_at timestamptz not null default now()
);

create table public.hotel_rooms (
  id uuid primary key default gen_random_uuid(),
  hotel_id uuid not null references public.hotels(id) on delete cascade,
  room_type text not null,
  occupancy integer not null check(occupancy > 0)
);

create table public.hotel_inventory (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.hotel_rooms(id),
  check_in date not null,
  check_out date not null,
  availability integer not null default 0,
  price numeric(12,2) not null,
  currency char(3) not null,
  status text not null default 'available'
);

create table public.transport_options (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  transport_type text not null,
  description text,
  price numeric(12,2) not null default 0,
  currency char(3) not null,
  supplier_id uuid references public.suppliers(id),
  supplier_reference text,
  status text not null default 'draft'
);

create table public.packages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  event_id uuid references public.events(id),
  base_price numeric(12,2) not null,
  currency char(3) not null,
  availability integer not null default 0,
  supplier_id uuid references public.suppliers(id),
  supplier_reference text,
  authorization_reference text,
  status text not null default 'draft',
  cancellation_policy text,
  is_demo boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.package_items (
  id uuid primary key default gen_random_uuid(),
  package_id uuid not null references public.packages(id) on delete cascade,
  item_type text not null,
  item_id uuid,
  quantity integer not null default 1
);

create table public.travellers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  full_name text not null,
  date_of_birth date,
  nationality text,
  passport_last4 text,
  created_at timestamptz not null default now()
);

create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  public_reference text not null unique,
  user_id uuid not null references public.profiles(id),
  event_id uuid references public.events(id),
  package_id uuid references public.packages(id),
  status public.booking_status not null default 'draft',
  currency char(3) not null,
  subtotal numeric(12,2) not null default 0,
  taxes_fees numeric(12,2) not null default 0,
  discount numeric(12,2) not null default 0,
  total numeric(12,2) not null default 0,
  cancellation_policy text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.booking_items (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  item_type text not null,
  item_id uuid,
  description text not null,
  quantity integer not null default 1,
  unit_price numeric(12,2) not null,
  currency char(3) not null
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id),
  provider text not null,
  provider_payment_id text,
  status public.payment_status not null default 'pending',
  amount numeric(12,2) not null,
  currency char(3) not null,
  transaction_reference text,
  idempotency_key text unique,
  raw_provider_reference jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.refunds (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid not null references public.payments(id),
  amount numeric(12,2) not null,
  reason text not null,
  status text not null default 'pending',
  provider_ref text,
  created_at timestamptz not null default now()
);

create table public.invoices (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null unique references public.bookings(id),
  invoice_number text not null unique,
  issued_at timestamptz not null default now(),
  payment_status public.payment_status not null,
  total numeric(12,2) not null,
  currency char(3) not null,
  document_uri text
);

create table public.promo_codes (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  discount_type text not null,
  discount_value numeric(12,2) not null,
  expires_at timestamptz,
  usage_limit integer,
  minimum_purchase numeric(12,2),
  active boolean not null default true
);

create table public.promo_redemptions (
  id uuid primary key default gen_random_uuid(),
  promo_code_id uuid not null references public.promo_codes(id),
  booking_id uuid not null references public.bookings(id),
  user_id uuid not null references public.profiles(id),
  redeemed_at timestamptz not null default now(),
  unique(promo_code_id, booking_id)
);

create table public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  booking_id uuid references public.bookings(id),
  subject text not null,
  status text not null default 'open',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  type text not null,
  title text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_user_id uuid references public.profiles(id),
  action text not null,
  entity_type text not null,
  entity_id uuid,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create index ticket_inventory_event_status_idx on public.ticket_inventory(event_id,status);
create index ticket_holds_expiry_idx on public.ticket_holds(expires_at);
create index bookings_user_status_idx on public.bookings(user_id,status);
create index payments_booking_idx on public.payments(booking_id);
create index events_start_idx on public.events(starts_at);

alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.events enable row level security;
alter table public.venues enable row level security;
alter table public.ticket_inventory enable row level security;
alter table public.packages enable row level security;
alter table public.hotels enable row level security;
alter table public.bookings enable row level security;
alter table public.booking_items enable row level security;
alter table public.payments enable row level security;
alter table public.travellers enable row level security;
alter table public.support_tickets enable row level security;
alter table public.notifications enable row level security;
alter table public.audit_logs enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.user_roles where user_id=auth.uid() and role in ('super_admin','admin','operations','support','finance')); $$;

create policy "public can view published events" on public.events for select using (status='published');
create policy "public can view available packages" on public.packages for select using (status='published');
create policy "public can view available inventory" on public.ticket_inventory for select using (status='available' and is_demo=true);
create policy "users view own bookings" on public.bookings for select using (auth.uid()=user_id or public.is_admin());
create policy "users view own booking items" on public.booking_items for select using (exists(select 1 from public.bookings b where b.id=booking_id and (b.user_id=auth.uid() or public.is_admin())));
create policy "users view own payments" on public.payments for select using (exists(select 1 from public.bookings b where b.id=booking_id and (b.user_id=auth.uid() or public.is_admin())));
create policy "users manage own travellers" on public.travellers for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "users view own notifications" on public.notifications for select using (auth.uid()=user_id);
create policy "users view own support" on public.support_tickets for select using (auth.uid()=user_id or public.is_admin());

-- Public booking references are intentionally separate from UUID primary keys.
create or replace function public.generate_booking_reference()
returns text language plpgsql as $$
declare ref text;
begin
  ref := 'SB-' || to_char(now(),'YYYY') || '-' || upper(substr(encode(gen_random_bytes(4),'hex'),1,8));
  return ref;
end $$;