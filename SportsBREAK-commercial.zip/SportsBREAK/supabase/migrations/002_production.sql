-- Production hardening for the schema in 001_initial.sql.
create extension if not exists pgcrypto;

alter table public.payments add column if not exists provider_transaction_id text;
alter table public.payments add column if not exists customer_phone text;
alter table public.payments add column if not exists provider_payload jsonb;
alter table public.payments add column if not exists metadata jsonb not null default '{}'::jsonb;
create unique index if not exists payments_provider_payment_uidx on public.payments(provider,provider_payment_id) where provider_payment_id is not null;

create table if not exists public.payment_webhook_events(
 id uuid primary key default gen_random_uuid(), provider text not null, event_id text not null, event_type text not null,
 payload jsonb not null, received_at timestamptz not null default now(), unique(provider,event_id)
);
alter table public.payment_webhook_events enable row level security;
revoke all on public.payment_webhook_events from anon, authenticated;

create or replace function public.generate_booking_reference() returns text
language plpgsql security definer set search_path=public as $$
declare ref text;
begin loop
 ref := 'SB-'||to_char(now(),'YYYY')||'-'||upper(substr(encode(gen_random_bytes(5),'hex'),1,10));
 exit when not exists(select 1 from public.bookings where public_reference=ref);
end loop; return ref; end $$;

create or replace function public.create_booking_hold(p_user_id uuid,p_package_id uuid,p_quantity integer default 1) returns jsonb
language plpgsql security definer set search_path=public as $$
declare p public.packages%rowtype; b public.bookings%rowtype; total numeric;
begin
 if p_user_id is null or p_package_id is null or p_quantity < 1 or p_quantity > 20 then raise exception 'Invalid booking request'; end if;
 select * into p from public.packages where id=p_package_id and status='published' and is_demo=false for update;
 if not found then raise exception 'Production package unavailable'; end if;
 if p.availability < p_quantity then raise exception 'Insufficient package availability'; end if;
 total := p.base_price*p_quantity;
 update public.packages set availability=availability-p_quantity where id=p.id;
 insert into public.bookings(public_reference,user_id,event_id,package_id,status,currency,subtotal,total,cancellation_policy)
 values(public.generate_booking_reference(),p_user_id,p.event_id,p.id,'awaiting_payment',p.currency,total,total,p.cancellation_policy) returning * into b;
 insert into public.booking_items(booking_id,item_type,item_id,description,quantity,unit_price,currency)
 values(b.id,'package',p.id,p.name,p_quantity,p.base_price,p.currency);
 return jsonb_build_object('id',b.id,'reference',b.public_reference,'total',b.total,'currency',b.currency);
end $$;

create or replace function public.create_mpesa_booking_hold(p_user_id uuid,p_package_id uuid,p_quantity integer default 1) returns jsonb
language sql security definer set search_path=public as $$ select public.create_booking_hold(p_user_id,p_package_id,p_quantity); $$;

create or replace function public.release_expired_holds() returns integer
language plpgsql security definer set search_path=public as $$
declare n integer:=0; b record;
begin
 -- Only release payment-stage bookings that were created through this hold flow.
 for b in select id,package_id from public.bookings where status='awaiting_payment' and created_at < now()-interval '15 minutes' for update loop
   update public.packages set availability=availability+(select coalesce(sum(quantity),0) from public.booking_items where booking_id=b.id and item_type='package' and item_id=b.package_id) where id=b.package_id;
   update public.bookings set status='cancelled',updated_at=now() where id=b.id;
   n:=n+1;
 end loop; return n;
end $$;

create or replace function public.mark_booking_paid(p_booking_id uuid,p_provider_payment_id text,p_provider text) returns void
language plpgsql security definer set search_path=public as $$
begin
 update public.payments set status='paid',updated_at=now() where booking_id=p_booking_id and provider=p_provider and provider_payment_id=p_provider_payment_id;
 update public.bookings set status='paid',updated_at=now() where id=p_booking_id and status in ('awaiting_payment','payment_processing');
end $$;

create index if not exists bookings_user_status_idx on public.bookings(user_id,status,created_at desc);
create index if not exists payments_booking_status_idx on public.payments(booking_id,status);
create index if not exists ticket_inventory_event_status_idx on public.ticket_inventory(event_id,status);
create index if not exists ticket_holds_expiry_idx on public.ticket_holds(expires_at);
create index if not exists audit_logs_created_idx on public.audit_logs(created_at desc);

-- Schedule public.release_expired_holds() with Supabase Cron every minute in production.
