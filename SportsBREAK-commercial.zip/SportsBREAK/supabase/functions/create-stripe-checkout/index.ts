import Stripe from 'https://esm.sh/stripe@18.5.0?target=deno';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.0';

const cors = {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type'};
Deno.serve(async req=>{
 if(req.method==='OPTIONS') return new Response('ok',{headers:cors});
 try{
  const auth=req.headers.get('Authorization'); if(!auth) throw new Error('Authentication required');
  const supabase=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const userClient=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_ANON_KEY')!,{global:{headers:{Authorization:auth}}});
  const {data:{user}}=await userClient.auth.getUser(); if(!user) throw new Error('Authentication required');
  const body=await req.json(); const packageId=String(body.package_id||''); const quantity=Math.max(1,Math.min(20,Number(body.quantity||1)));
  const {data:pkg,error:pkgError}=await supabase.from('packages').select('id,name,base_price,currency,status,availability').eq('id',packageId).single();
  if(pkgError||!pkg||pkg.status!=='published'||pkg.availability<quantity) throw new Error('Package unavailable');
  const {data:booking,error:bookingError}=await supabase.rpc('create_booking_hold',{p_user_id:user.id,p_package_id:pkg.id,p_quantity:quantity});
  if(bookingError) throw bookingError;
  const bookingId=booking.id||booking[0]?.id; const reference=booking.reference||booking[0]?.reference; if(!bookingId) throw new Error('Could not create booking hold');
  const stripe=new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!,{apiVersion:'2025-08-27.basil'});
  const currency=String(pkg.currency).toLowerCase(); const unitAmount=Math.round(Number(pkg.base_price)*100);
  const session=await stripe.checkout.sessions.create({mode:'payment',customer_email:String(body.email||user.email||''),line_items:[{price_data:{currency,product_data:{name:`${pkg.name} · SportsBREAK`,metadata:{package_id:pkg.id,booking_reference:reference}},unit_amount:unitAmount},quantity}],metadata:{booking_id:bookingId,booking_reference:reference,user_id:user.id},success_url:String(body.success_url||'https://example.com/trips'),cancel_url:String(body.cancel_url||'https://example.com/checkout')});
  await supabase.from('payments').insert({booking_id:bookingId,provider:'stripe',provider_payment_id:session.id,status:'pending',amount:Number(pkg.base_price)*quantity,currency:pkg.currency,transaction_reference:session.id,raw_provider_reference:{checkout_session_id:session.id}});
  return new Response(JSON.stringify({url:session.url,booking_reference:reference}),{headers:{...cors,'Content-Type':'application/json'}});
 }catch(e){return new Response(JSON.stringify({error:e instanceof Error?e.message:'Payment setup failed'}),{status:400,headers:{...cors,'Content-Type':'application/json'}})}
});
