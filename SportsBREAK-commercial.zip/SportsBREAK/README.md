# SportsBREAK — production-ready commercial foundation

SportsBREAK is an independent football travel and matchday-experience marketplace. The repository is built around the supplied product specification: React + TypeScript, Tailwind CSS, Supabase/PostgreSQL/Auth, server-side payment functions, Stripe and Safaricom Daraja architecture, supplier authorization, RBAC, RLS, auditability, checkout holds, customer trips, and responsive UX.

## What is included

- Premium responsive public website: Home, Matches, Packages, Hotels, Travel, About, Help, legal routes.
- Match detail and six-stage checkout UX: Experience → Travellers → Hotel/Transport → Review → Payment → Confirmation.
- Supabase Auth sign-in/sign-up and customer My Trips area.
- Admin console shell with operations/security indicators.
- Production-oriented database migration with booking references, booking holds, webhook idempotency ledger, payment indexes and hold release function.
- Stripe Checkout Edge Function + signature-verified webhook flow.
- Daraja M-Pesa STK Push + callback verification architecture.
- Environment-based secrets. No provider secret is shipped to the browser.
- Test/demo inventory is explicitly represented in code and is not presented as real club-authorized inventory.

The source specification requires that every real event/ticket listing be backed by a supplier/authorization record, that fake tickets/credentials are never generated, and that integrations only be called live after real credentials and successful API tests confirm them. See the supplied specification for the full requirement set. fileciteturn1file0L15-L31

## Run locally

```bash
npm install
cp .env.example .env.local
npm run dev
```

## Production wiring checklist

1. **Supabase** — create a project; run `supabase/migrations/001_initial.sql`, then `002_production.sql`.
2. **Authentication** — enable email/password and configure the production site URL and redirect URLs.
3. **Environment** — put only `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in the browser build. Put service-role, Stripe and Daraja secrets in Supabase Edge Function secrets.
4. **Real inventory** — create suppliers, supplier authorizations, venues, events, ticket inventory, hotels, transport and packages through secured admin operations. Set `is_demo=false` only for inventory you have actually authorized and verified.
5. **Ticket fulfillment** — keep supplier references and authorization evidence server-side; never expose credentials to customers.
6. **Stripe** — create the production webhook endpoint for `stripe-webhook`, set the webhook secret, configure allowed currencies/products, and test successful and failed payments.
7. **Daraja** — create/configure the legitimate Safaricom Daraja app, shortcode/passkey and callback URL; test STK Push and callback handling in sandbox before production.
8. **Email** — connect a transactional email provider through server-side secrets and add templates for registration, verification, booking, payment, fulfillment, cancellation, refund and password reset.
9. **Cron** — schedule `release_expired_holds()` every minute (or another safe interval) so abandoned 15-minute holds return to inventory.
10. **Deployment** — deploy the Vite frontend to your preferred static/edge host and Supabase Edge Functions to the same production project.
11. **Domain/SEO** — replace the example canonical URL in `index.html` and `public/robots.txt`/`sitemap.xml` with the real SportsBREAK domain.
12. **Security** — verify RLS policies, RBAC, server-side authorization, rate limits, secure headers, audit logs, webhook idempotency and error handling before enabling real payments.

## Real-data activation

The frontend intentionally ships with clearly identifiable demo content so it cannot accidentally imply that placeholder clubs/events are official inventory. Replace that data through your authenticated Supabase admin workflow once your authorized supplier/event records are loaded.

The supplied requirements specifically call for clearly labeled test/real data and prohibit fabricated club authorization. fileciteturn1file0L957-L987

## Payment safety

- Frontend payment success is never trusted.
- Stripe payment state is changed by the verified webhook.
- M-Pesa payment state is changed by the verified server callback.
- Public booking references are random and separate from database UUIDs.
- Inventory is reserved before payment and released after expiry.
- Provider secrets must never be placed in `VITE_*` variables.

## Before launch

Run:

```bash
npm run typecheck
npm run build
```

Then perform real sandbox/provider tests for Stripe and Daraja, verify the callback URLs, test expired holds and duplicate webhooks, create a real authorized supplier record, and only then switch production inventory/payment credentials on.

This repository is an integration-ready commercial foundation. It does **not** claim that your private supplier, Stripe or Daraja credentials are live because those credentials have not been entered or tested in this environment.
