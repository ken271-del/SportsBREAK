export type Currency = 'GBP' | 'KES' | 'USD' | 'EUR';
export type BookingStatus = 'draft'|'awaiting_payment'|'payment_processing'|'paid'|'confirmed'|'supplier_confirmation_pending'|'ticket_issued'|'completed'|'cancelled'|'refunded';
export type PaymentStatus = 'pending'|'processing'|'paid'|'failed'|'cancelled'|'refund_pending'|'refunded';

export interface EventItem { id:string; name:string; home_team:string; away_team:string; league:string; venue:string; city:string; country:string; starts_at:string; image_url:string; min_price:number; currency:Currency; availability:number; status:'draft'|'published'|'cancelled'; }
export interface PackageItem { id:string; name:string; description:string; event_id:string; package_type:string; base_price:number; currency:Currency; availability:number; image_url:string; cancellation_policy:string; }
export interface Booking { id:string; reference:string; status:BookingStatus; total:number; currency:Currency; created_at:string; event_name?:string; destination?:string; }
