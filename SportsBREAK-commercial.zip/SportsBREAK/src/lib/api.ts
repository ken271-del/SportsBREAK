import { supabase } from './supabase';
export async function currentUser(){ const {data}=await supabase.auth.getUser(); return data.user; }
export async function signIn(email:string,password:string){ return supabase.auth.signInWithPassword({email,password}); }
export async function signUp(email:string,password:string,fullName:string){ return supabase.auth.signUp({email,password,options:{data:{full_name:fullName}}}); }
export async function signOut(){ return supabase.auth.signOut(); }
export async function createCheckout(payload:Record<string,unknown>){ return supabase.functions.invoke('create-stripe-checkout',{body:payload}); }
export async function createMpesa(payload:Record<string,unknown>){ return supabase.functions.invoke('mpesa-stk',{body:payload}); }
