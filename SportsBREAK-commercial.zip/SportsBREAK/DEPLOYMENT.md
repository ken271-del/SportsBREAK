# SportsBREAK deployment runbook

## 1. Database

- Create a Supabase project.
- Run `001_initial.sql` followed by `002_production.sql` in the SQL editor.
- Create at least one trusted admin user, then add the matching row to `user_roles` with the appropriate role.
- Configure a scheduled job to call `select public.release_expired_holds();` every minute.

## 2. Real supplier inventory

Create, verify and publish records in this order:

`suppliers → supplier_authorizations → venues → events → ticket_inventory → hotels/hotel_rooms/hotel_inventory → transport_options → packages`

Only set `is_demo=false` after the supplier/authorization evidence has been verified. The supplied product specification requires every real listing to support a supplier/authorization record and forbids fabricated authorization or tickets.

## 3. Stripe

Set the Edge Function secrets:

- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`

Deploy `create-stripe-checkout` and `stripe-webhook`. Point the Stripe webhook to the deployed `stripe-webhook` function and subscribe to the Checkout events your flow uses. Test duplicate delivery and failed payment paths.

## 4. M-Pesa / Daraja

Set:

- `MPESA_ENVIRONMENT`
- `MPESA_CONSUMER_KEY`
- `MPESA_CONSUMER_SECRET`
- `MPESA_SHORTCODE`
- `MPESA_PASSKEY`
- `MPESA_TRANSACTION_TYPE`
- `MPESA_CALLBACK_URL`

Deploy `mpesa-stk` and `mpesa-callback`. Complete sandbox STK Push + callback tests before production credentials are enabled.

## 5. Frontend

```bash
npm install
npm run typecheck
npm run build
```

Deploy the generated `dist/` directory. Set the Vite environment variables at build time.

## 6. Launch gate

Do not announce payment/ticket integrations as live until successful provider API tests have been completed with the actual authorized credentials. The supplied specification explicitly requires this distinction.
